// let lastUpdate = Date.now()
// let grid = document.querySelector('.grid')

// grid.style.backgroundPositionY = '0px'

// function animate() {
//   // if (Date.now() - lastUpdate > 100) {
//     // console.log('test')    
//     grid.style.backgroundPositionY = parseInt(
//       grid.style.backgroundPositionY, 10
//     ) + 20 + 'px'
//     // lastUpdate = Date.now()
//   // }
//   requestAnimationFrame(animate)
// }

// animate()