A Pen created at CodePen.io. You can find this one at https://codepen.io/overra/pen/Kapawo.

 Finally got around to watching Kung Fury and wanted to try replicating the time hack scene in CSS.

Background provided by Sven Scheuermeier https://unsplash.com/photos/tqzqzH8hb5A